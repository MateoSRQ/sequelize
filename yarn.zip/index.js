const data = require('./CURSO_TEST.json');
const tedious = require('tedious');
const { Sequelize, Model, DataTypes } = require('sequelize');
const moment = require('moment')


let facultades = {}
//let escuelas   = {}




const sequelize = new Sequelize(
    'academico_etl',
    'sa',
    'sa',
    {
        host: 'localhost',
        dialect: 'mssql'
    }
);

const Facultad = sequelize.define('Facultad',
    {
    // Model attributes are defined here
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    cod_facultad: {
        type: DataTypes.STRING,
        allowNull: false
    },
    nombre: {
        type: DataTypes.STRING,
        allowNull: false
    },
    abreviatura: {
        type: DataTypes.STRING,
        allowNull: false
    },
    estadoAuditoria: {
        type: DataTypes.BOOLEAN,
        allowNull: true
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        type: DataTypes.NOW,
        defaultValue: moment.utc().format('YYYY-MM-DD HH:mm:ss'),
    },
    createdBy: {
        type: DataTypes.STRING,
        allowNull: false
    },
    modifiedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        type: DataTypes.NOW,
        defaultValue: moment.utc().format('YYYY-MM-DD HH:mm:ss'),
    },
    modifiedBy: {
        type: DataTypes.STRING,
        allowNull: false
    },
    activo: {
        type: DataTypes.BOOLEAN,
        allowNull: true
    }
}, {
        timestamps: false,
        //schema:
        //paranoid: true,
        underscored: true,
        freezeTableName: true,
        tableName: 'Facultad'
});


sequelize.authenticate().then(() => {
    console.log('Connection has been established successfully.');
    // FACULTADES
    for (let d of data) {
        if (facultades[d.FAC_FACCODI.toString()] == undefined) {
            facultades[d.FAC_FACCODI.toString()] = {
                FAC_FACCODI: d.FAC_FACCODI.toString(),
                FAC_FACNOMB: d.FAC_FACNOMB.toString(),
                FAC_FACNICK: d.FAC_FACNICK.toString(),
                FAC_FACANR: d.FAC_FACANR.toString(),
                ESCUELAS: {}
            }
        }
        if (facultades[d.FAC_FACCODI.toString()].ESCUELAS[d.ESC_CARCODI.toString()] == undefined) {
            facultades[d.FAC_FACCODI.toString()].ESCUELAS[d.ESC_CARCODI.toString()] = {
                ESC_CARCODI: d.ESC_CARCODI.toString(),
                ESC_FACCODI: d.ESC_FACCODI.toString(),
                ESC_CARNICK: d.ESC_CARNICK.toString(),
                ESC_CARANR: d.ESC_CARANR.toString(),
                ESC_CARSEME: d.ESC_CARSEME.toString(),
                ESC_CARHDUR: d.ESC_CARHDUR.toString(),
                PLANES: {}
            }
        }
        if (facultades[d.FAC_FACCODI.toString()].ESCUELAS[d.ESC_CARCODI.toString()].PLANES[d.PLAN_CRRCODI.toString()] == undefined) {
            facultades[d.FAC_FACCODI.toString()].ESCUELAS[d.ESC_CARCODI.toString()].PLANES[d.PLAN_CRRCODI.toString()] = {
                PLAN_CRRCODI: d.PLAN_CRRCODI.toString(),
                PLAN_CRRDESC: d.PLAN_CRRDESC.toString(),
                PLAN_CRRDHRS: d.PLAN_CRRDHRS.toString(),
                PLAN_CRRESTA: d.PLAN_CRRESTA.toString(),
                CURSOS: {}
            }
        }
        if (facultades[d.FAC_FACCODI.toString()].ESCUELAS[d.ESC_CARCODI.toString()].PLANES[d.PLAN_CRRCODI.toString()].CURSOS[d.CURSO_CURCODI.toString()] == undefined) {
            facultades[d.FAC_FACCODI.toString()].ESCUELAS[d.ESC_CARCODI.toString()].PLANES[d.PLAN_CRRCODI.toString()].CURSOS[d.CURSO_CURCODI.toString()] = {
                CURSO_CURCODI: d.CURSO_CURCODI.toString(),
                CURSO_CRRCODI: d.CURSO_CRRCODI.toString(),
                CURSO_CURNICK: d?.CURSO_CURNICK?.toString(),
                CURSO_CURESTA: d.CURSO_CURESTA.toString(),

                CURSO_CURNCRE: d.CURSO_CURNCRE.toString(),
                CURSO_CURSEME: d.CURSO_CURSEME.toString(),
                CURSO_CURTIPO: d.CURSO_CURTIPO.toString(),
                CURSO_CURHTEO: d.CURSO_CURHTEO.toString(),
                //
                // CURSO_CURHPRA: d.CURSO_CURHPRA.toString(),
                // CURSO_CURTHRS: d.CURSO_CURTHRS.toString(),
                // CURSO_CURDHRS: d.CURSO_CURDHRS.toString(),
                //
                // CURSO_CURHLAB: d.CURSO_CURHLAB.toString(),
                //CURSO_CURTUSO: d.CURSO_CURTUSO.toString(),

            }
        }
    }


    console.log(JSON.stringify(facultades, null, 4));
    //console.log(facultades.length)

    /*
    (async function() {
        for (let f in facultades) {
            console.log(facultades[f])
            const facultad = Facultad.build({
                cod_facultad: facultades[f].FAC_FACCODI,
                abreviatura: facultades[f].FAC_FACNICK.substring(0,50),
                nombre: facultades[f].FAC_FACNOMB,
                activo: true,
                createdBy: 'SYSTEM',
                modifiedBy: 'SYSTEM'
            });
            await facultad.save();

        }
    })();
*/



}).catch((error) => {
    console.error('Unable to connect to the database: ', error);
});

/*



 */